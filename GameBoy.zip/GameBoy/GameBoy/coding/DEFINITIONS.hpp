#pragma

#define MAIN_MENU_BUTTON_1_FILEPATH "mainmenu/tetris_button.png"
#define MAIN_MENU_BUTTON_2_FILEPATH "mainmenu/minesweeper_button.png"
#define MAIN_MENU_BUTTON_3_FILEPATH "mainmenu/xonix_button.png"
#define MAIN_MENU_BUTTON_4_FILEPATH "mainmenu/netwalk_button.png"
#define MAIN_MENU_BACKGROUND_FILEPATH "mainmenu/background.png"