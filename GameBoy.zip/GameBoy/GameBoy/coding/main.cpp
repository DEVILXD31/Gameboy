#include <iostream>
#include <SFML/Graphics.hpp>
#include "MainMenu.hpp"


int main(){
    GameBoy::MainMenu();
    return 0;
}
