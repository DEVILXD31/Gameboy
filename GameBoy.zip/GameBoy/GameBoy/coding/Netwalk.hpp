namespace GameBoy{
    void Netwalk();
}