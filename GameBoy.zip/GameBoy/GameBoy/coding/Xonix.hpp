
namespace GameBoy{
    int Xonix();
}