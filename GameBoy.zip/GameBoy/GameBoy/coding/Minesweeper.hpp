#include "DEFINITIONS.hpp"

namespace GameBoy{
    
    int Minesweeper();
}