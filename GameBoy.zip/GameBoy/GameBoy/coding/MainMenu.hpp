#include <iostream>
#include <SFML/Graphics.hpp>

namespace GameBoy{
    
    int MainMenu();
}